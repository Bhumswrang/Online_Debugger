package com.bill.bill.exception;

public class BillIdNotExistException extends RuntimeException{
    private static final long serialVersionUID = 1L;
}

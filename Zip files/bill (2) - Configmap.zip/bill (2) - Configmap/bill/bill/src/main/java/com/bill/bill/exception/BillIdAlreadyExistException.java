package com.bill.bill.exception;

public class BillIdAlreadyExistException extends RuntimeException{
    private static final long serialVersionUID = 1L;
}

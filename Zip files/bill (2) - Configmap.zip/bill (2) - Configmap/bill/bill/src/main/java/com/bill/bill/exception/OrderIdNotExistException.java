package com.bill.bill.exception;

public class OrderIdNotExistException extends RuntimeException{
    private static final long serialVersionUID = 1L;
}

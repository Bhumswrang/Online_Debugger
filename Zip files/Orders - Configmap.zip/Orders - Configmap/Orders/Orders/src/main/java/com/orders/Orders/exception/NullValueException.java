package com.orders.Orders.exception;

public class NullValueException extends RuntimeException{
    private static final long serialVersionUID = 1L;
}

package com.orders.Orders.exception;

public class OrderWithIdAlreadyExistException extends RuntimeException{
    private static final long serialVersionUID = 1L;
}
